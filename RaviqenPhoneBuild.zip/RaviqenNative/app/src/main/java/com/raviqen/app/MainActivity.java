package com.raviqen.app;

import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.graphics.Color;import android.widget.*;import android.content.*;import java.util.*;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,7,11)); getWindow().setNavigationBarColor(Color.rgb(7,7,11));
    web=new WebView(this); web.setBackgroundColor(Color.BLACK); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
