# Build Raviqen from your phone

This project includes a GitHub Actions workflow that builds the APK in the cloud. You do NOT need Android Studio or Flutter on your phone.

1. Create a GitHub account if you do not have one.
2. Create a new repository, e.g. `raviqen`.
3. Upload the contents of this folder to the repository (the folder that contains `settings.gradle`, `build.gradle`, and `app/`).
4. Open the repository's **Actions** tab.
5. Select **Build Raviqen APK** and press **Run workflow**. If you pushed to `main`, it can also run automatically.
6. Wait for the green check.
7. Open the completed workflow run and scroll to **Artifacts**.
8. Download **Raviqen-debug-apk** on your phone, unzip it, and install `app-debug.apk`.

The APK is a debug build intended for testing. Android may ask you to allow installation from the browser/file manager.
