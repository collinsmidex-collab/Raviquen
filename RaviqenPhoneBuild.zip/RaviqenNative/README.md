# Raviqen — Standalone Android V1

This is a native Android project. It does **not** use Flutter or Supabase. The UI is bundled locally in the APK and the Java launcher uses Android WebView, so the app has no third-party runtime dependency.

## Included V1
- Raviqen branded home feed
- Vertical social-video style feed UI
- Like, comment, share, save and follow interactions
- Discover/search-style screen
- Create/upload video picker
- Notifications
- Profile, creator analytics/earnings placeholders and settings entries
- Local bundled UI; no API keys or backend credentials

## Build
Requires Android Studio/Android SDK and Gradle. Open this folder in Android Studio and choose **Build > Build APK(s)**.

The environment used to generate this source project does not contain the Android SDK, so an APK cannot be compiled inside this workspace yet.
