# Raviqen Android V2

Native Android/WebView hybrid build. No Flutter and no Supabase.

V2 adds persistent local profiles, login/signup demo flow, working video picker and preview, published local feed entries for the current device, likes, saves, follows, comments, search, notifications, profile editing, settings, creator analytics and earnings screens.

Important: this build is a real installable APK, but multi-device/server persistence is not included because no production backend credentials are configured. The UI is structured so a secure backend can be connected later without putting secrets in the APK.


## Launcher icon
The Android launcher icon is the Raviqen purple R mark on a dark background, configured as the official app and round icon.
